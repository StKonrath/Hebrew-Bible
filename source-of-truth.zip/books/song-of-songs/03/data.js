window.__chapterData = {
  "title": "(Stub) Add data.json for this chapter",
  "verses": [
    {
      "ref": "1:1",
      "he": "",
      "en": "",
      "tr": ""
    }
  ],
  "lexicon": [],
  "grammar": [],
  "exercises": [],
  "generated_at": "2026-02-27"
};
